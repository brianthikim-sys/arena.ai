import type { Restaurant } from "../hooks/useRestaurantRoulette";

interface Props {
  restaurant: Restaurant | null;
  locked: boolean;
  onToggleLock: () => void;
  onInspect: () => void;
  spinning: boolean;
  finalSpinning: boolean;
  index: number;
}

function PriceLevel({ level }: { level: number | null }) {
  if (level === null) return <span className="price-label">—</span>;
  return (
    <span className="price-label">
      {"$".repeat(level)}
      <span style={{ opacity: 0.3 }}>{"$".repeat(Math.max(0, 4 - level))}</span>
    </span>
  );
}

function StarRating({ rating }: { rating: number | null }) {
  if (rating === null) return null;
  const full = Math.floor(rating);
  const frac = rating - full;
  return (
    <span className="star-row">
      {Array.from({ length: 5 }, (_, i) => {
        if (i < full) return <span key={i} className="star filled">★</span>;
        if (i === full && frac >= 0.5) return <span key={i} className="star half">★</span>;
        return <span key={i} className="star empty">★</span>;
      })}
      <span className="rating-num">{rating.toFixed(1)}</span>
    </span>
  );
}

function TypeTag({ type }: { type: string }) {
  const label = type.replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
  return <span className="type-tag">{label}</span>;
}

export default function RestaurantCard({ restaurant, locked, onToggleLock, onInspect, spinning, finalSpinning, index }: Props) {
  const delay = `${index * 120}ms`;
  const isAnimating = (spinning && !locked) || finalSpinning;

  return (
    <div
      className={[
        "slot-card",
        locked ? "slot-card--locked" : "",
        isAnimating ? "slot-card--spinning" : "",
        !restaurant ? "slot-card--empty" : "",
      ]
        .filter(Boolean)
        .join(" ")}
      style={{ animationDelay: delay }}
    >
      {/* Photo */}
      <div
        className={`card-photo-wrap ${restaurant && !isAnimating ? "card-photo-wrap--clickable" : ""}`}
        onClick={() => restaurant && !isAnimating && onInspect()}
        title={restaurant ? "View details" : undefined}
        role={restaurant ? "button" : undefined}
        tabIndex={restaurant && !isAnimating ? 0 : undefined}
        onKeyDown={(e) => e.key === "Enter" && restaurant && !isAnimating && onInspect()}
      >
        {restaurant?.photo_url ? (
          <img
            src={restaurant.photo_url}
            alt={restaurant.name}
            className="card-photo"
            loading="lazy"
          />
        ) : (
          <div className="card-photo card-photo--placeholder">
            {restaurant ? "🍽️" : "?"}
          </div>
        )}
        {restaurant && !isAnimating && (
          <div className="card-inspect-hint">🔍 View details</div>
        )}

        {/* Open/closed badge */}
        {restaurant && restaurant.open_now !== null && (
          <span className={`open-badge ${restaurant.open_now ? "open-badge--open" : "open-badge--closed"}`}>
            {restaurant.open_now ? "OPEN" : "CLOSED"}
          </span>
        )}

        {/* Price level overlay */}
        {restaurant && (
          <span className="price-overlay">
            <PriceLevel level={restaurant.price_level} />
          </span>
        )}
      </div>

      {/* Body */}
      <div className="card-body">
        {restaurant ? (
          <>
            <h3 className="card-name">{restaurant.name}</h3>
            <StarRating rating={restaurant.rating} />
            {restaurant.user_ratings_total > 0 && (
              <p className="card-reviews">{restaurant.user_ratings_total.toLocaleString()} reviews</p>
            )}
            <p className="card-address">📍 {restaurant.address}</p>
            {restaurant.types.length > 0 && (
              <div className="type-tags">
                {restaurant.types.slice(0, 2).map((t) => (
                  <TypeTag key={t} type={t} />
                ))}
              </div>
            )}
          </>
        ) : (
          <div className="card-empty-state">
            <span className="card-empty-icon">🎰</span>
            <p>Hit Spin to reveal</p>
          </div>
        )}
      </div>

      {/* Lock button */}
      {restaurant && (
        <button
          className={`lock-btn ${locked ? "lock-btn--locked" : ""}`}
          onClick={onToggleLock}
          title={locked ? "Unlock this slot" : "Lock this choice in"}
          aria-pressed={locked}
        >
          {locked ? "🔒 Locked" : "🔓 Lock In"}
        </button>
      )}

      {/* Locked overlay shimmer */}
      {locked && <div className="lock-shimmer" />}
    </div>
  );
}
