import { useState, useMemo } from "react";
import type { Restaurant } from "../hooks/useRestaurantRoulette";

export interface Filters {
  prices: Set<number>;   // 1-4; empty = all
  openNow: boolean;
  cuisine: string | null;
}

export const DEFAULT_FILTERS: Filters = {
  prices: new Set(),
  openNow: false,
  cuisine: null,
};

// Returns `pool` with all active filters applied
export function applyFilters(pool: Restaurant[], filters: Filters): Restaurant[] {
  return pool.filter((r) => {
    if (filters.prices.size > 0 && r.price_level !== null) {
      if (!filters.prices.has(r.price_level)) return false;
    }
    if (filters.openNow && r.open_now !== true) return false;
    if (filters.cuisine) {
      if (!r.types.includes(filters.cuisine)) return false;
    }
    return true;
  });
}

// Top cuisine types from the pool, capped at 8
function topCuisines(pool: Restaurant[]): string[] {
  const counts = new Map<string, number>();
  const skip = new Set(["point_of_interest", "establishment", "food", "restaurant", "store"]);
  for (const r of pool) {
    for (const t of r.types) {
      if (!skip.has(t)) counts.set(t, (counts.get(t) ?? 0) + 1);
    }
  }
  return [...counts.entries()]
    .sort((a, b) => b[1] - a[1])
    .slice(0, 8)
    .map(([t]) => t);
}

function formatCuisine(t: string) {
  return t.replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
}

interface Props {
  pool: Restaurant[];
  filters: Filters;
  onChange: (f: Filters) => void;
  filteredCount: number;
}

const PRICE_LABELS: Record<number, string> = { 1: "$", 2: "$$", 3: "$$$", 4: "$$$$" };

export default function FilterPanel({ pool, filters, onChange, filteredCount }: Props) {
  const [open, setOpen] = useState(false);
  const cuisines = useMemo(() => topCuisines(pool), [pool]);

  const activeCount =
    filters.prices.size +
    (filters.openNow ? 1 : 0) +
    (filters.cuisine ? 1 : 0);

  function togglePrice(p: number) {
    const next = new Set(filters.prices);
    next.has(p) ? next.delete(p) : next.add(p);
    onChange({ ...filters, prices: next });
  }

  function clearAll() {
    onChange(DEFAULT_FILTERS);
  }

  return (
    <div className="filter-wrap">
      {/* Trigger row */}
      <div className="filter-trigger-row">
        <button
          className={`filter-toggle-btn ${open ? "filter-toggle-btn--open" : ""}`}
          onClick={() => setOpen((v) => !v)}
          aria-expanded={open}
        >
          <span className="filter-icon">⚙️</span>
          Filters
          {activeCount > 0 && (
            <span className="filter-badge">{activeCount}</span>
          )}
          <span className="filter-chevron">{open ? "▲" : "▼"}</span>
        </button>

        {activeCount > 0 && (
          <span className="filter-pool-count">
            {filteredCount} restaurant{filteredCount !== 1 ? "s" : ""} match
          </span>
        )}
      </div>

      {/* Expanded panel */}
      {open && (
        <div className="filter-panel">
          {/* Price */}
          <div className="filter-group">
            <span className="filter-group-label">Price</span>
            <div className="filter-pills">
              {[1, 2, 3, 4].map((p) => (
                <button
                  key={p}
                  className={`filter-pill ${filters.prices.has(p) ? "filter-pill--active" : ""}`}
                  onClick={() => togglePrice(p)}
                >
                  {PRICE_LABELS[p]}
                </button>
              ))}
            </div>
          </div>

          {/* Open now */}
          <div className="filter-group">
            <span className="filter-group-label">Availability</span>
            <button
              className={`filter-pill ${filters.openNow ? "filter-pill--active" : ""}`}
              onClick={() => onChange({ ...filters, openNow: !filters.openNow })}
            >
              {filters.openNow ? "✓ " : ""}Open now
            </button>
          </div>

          {/* Cuisine */}
          {cuisines.length > 0 && (
            <div className="filter-group">
              <span className="filter-group-label">Cuisine</span>
              <div className="filter-pills filter-pills--wrap">
                {cuisines.map((c) => (
                  <button
                    key={c}
                    className={`filter-pill ${filters.cuisine === c ? "filter-pill--active" : ""}`}
                    onClick={() =>
                      onChange({ ...filters, cuisine: filters.cuisine === c ? null : c })
                    }
                  >
                    {formatCuisine(c)}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Clear */}
          {activeCount > 0 && (
            <button className="filter-clear-btn" onClick={clearAll}>
              Clear all filters
            </button>
          )}

          {filteredCount < 3 && activeCount > 0 && (
            <p className="filter-warn">
              ⚠️ Only {filteredCount} restaurant{filteredCount !== 1 ? "s" : ""} match — try relaxing a filter.
            </p>
          )}
        </div>
      )}
    </div>
  );
}
