import { useState, useCallback, useMemo } from "react";
import { useRestaurantRoulette } from "../hooks/useRestaurantRoulette";
import { usePlaceDetail } from "../hooks/usePlaceDetail";
import FilterPanel, { applyFilters, DEFAULT_FILTERS } from "./FilterPanel";
import type { Filters } from "./FilterPanel";
import type { Restaurant } from "../hooks/useRestaurantRoulette";
import RestaurantCard from "./RestaurantCard";
import PlaceDetailModal from "./PlaceDetailModal";
import ComparisonView from "./ComparisonView";

const RADIUS_OPTIONS = [
  { label: "500m", value: 500 },
  { label: "1 km", value: 1000 },
  { label: "2 km", value: 2000 },
  { label: "5 km", value: 5000 },
];

function GeolocationButton({ onLocate }: { onLocate: (lat: number, lng: number) => void }) {
  const [geoLoading, setGeoLoading] = useState(false);
  const [geoError, setGeoError] = useState<string | null>(null);

  const handleClick = () => {
    if (!navigator.geolocation) {
      setGeoError("Geolocation not supported");
      return;
    }
    setGeoLoading(true);
    setGeoError(null);
    navigator.geolocation.getCurrentPosition(
      (pos) => { setGeoLoading(false); onLocate(pos.coords.latitude, pos.coords.longitude); },
      (err) => {
        setGeoLoading(false);
        setGeoError("Location denied — using demo data");
        console.warn("Geolocation error:", err.message);
        onLocate(40.7128, -74.006);
      },
      { timeout: 8000 }
    );
  };

  return (
    <div className="geo-wrap">
      <button className="geo-btn" onClick={handleClick} disabled={geoLoading}>
        {geoLoading ? <span className="spinner-dot" /> : "📍"}
        {geoLoading ? "Locating…" : "Use My Location"}
      </button>
      {geoError && <p className="geo-error">{geoError}</p>}
    </div>
  );
}

function SpinCounter({ count }: { count: number }) {
  if (count === 0) return null;
  return (
    <div className="spin-counter">
      <span className="spin-counter-num">{count}</span>
      <span className="spin-counter-label">spin{count !== 1 ? "s" : ""}</span>
    </div>
  );
}

function WinnerBanner({
  winner,
  onChangeMind,
}: {
  winner: Restaurant;
  onChangeMind: () => void;
}) {
  const mapsDirectionsUrl = `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(
    winner.name + " " + winner.address
  )}`;
  const uberEatsUrl = `https://www.ubereats.com/search?q=${encodeURIComponent(winner.name)}`;
  const doordashUrl = `https://www.doordash.com/search/store/${encodeURIComponent(winner.name)}/`;

  return (
    <div className="winner-banner">
      {/* Photo behind the banner */}
      {winner.photo_url && (
        <div className="winner-photo-wrap">
          <img src={winner.photo_url} alt={winner.name} className="winner-photo" />
          <div className="winner-photo-overlay" />
        </div>
      )}

      <div className="winner-content">
        <div className="winner-confetti" aria-hidden>
          {"🎉✨🍽️✨🎉".split("").map((c, i) => (
            <span key={i} className="confetti-piece" style={{ animationDelay: `${i * 0.12}s` }}>
              {c}
            </span>
          ))}
        </div>
        <p className="winner-label">Tonight's dinner</p>
        <h2 className="winner-name">{winner.name}</h2>
        <p className="winner-address">📍 {winner.address}</p>

        <div className="winner-actions">
          <a href={mapsDirectionsUrl} target="_blank" rel="noopener noreferrer" className="winner-cta winner-cta--maps">
            🗺️ Get Directions
          </a>
          <a href={uberEatsUrl} target="_blank" rel="noopener noreferrer" className="winner-cta winner-cta--uber">
            🟣 Uber Eats
          </a>
          <a href={doordashUrl} target="_blank" rel="noopener noreferrer" className="winner-cta winner-cta--dash">
            🔴 DoorDash
          </a>
        </div>

        <button className="btn-secondary winner-change-mind" onClick={onChangeMind}>
          ← Change mind
        </button>
      </div>
    </div>
  );
}

export default function SlotMachine() {
  const {
    pool,
    slots,
    locked,
    status,
    spinCount,
    loading,
    error,
    spin,
    finalSpin,
    undecide,
    toggleLock,
    reset,
    fetchAndSpin,
    isSpinning,
    isFinalSpinning,
    isDecided,
  } = useRestaurantRoulette();

  const placeDetail = usePlaceDetail();
  const [inspectedIndex, setInspectedIndex] = useState<number | null>(null);
  const [isComparing, setIsComparing] = useState(false);
  const [chosenWinner, setChosenWinner] = useState<Restaurant | null>(null);
  const [filters, setFilters] = useState<Filters>(DEFAULT_FILTERS);

  const [radius, setRadius] = useState(1500);
  const [located, setLocated] = useState(false);

  // Apply filters to the raw pool for spin selection
  const filteredPool = useMemo(() => applyFilters(pool, filters), [pool, filters]);

  const handleLocate = useCallback(
    (lat: number, lng: number) => {
      setLocated(true);
      const filtered = applyFilters(pool, filters);
      fetchAndSpin(lat, lng, radius);
      // fetchAndSpin will re-fetch and call spin with fresh pool;
      // filter is applied at spin time via the filteredPool memo
    },
    [fetchAndSpin, pool, filters, radius]
  );

  const handleSpin = useCallback(() => {
    spin(filteredPool.length >= 3 ? filteredPool : pool);
  }, [spin, filteredPool, pool]);

  const handleFetchAndSpin = useCallback(
    (lat: number, lng: number) => {
      setLocated(true);
      fetchAndSpin(lat, lng, radius);
    },
    [fetchAndSpin, radius]
  );

  const handleReset = useCallback(() => {
    reset();
    setLocated(false);
    setIsComparing(false);
    setChosenWinner(null);
  }, [reset]);

  const handleInspect = useCallback((index: number) => {
    const restaurant = slots[index];
    if (!restaurant) return;
    setInspectedIndex(index);
    placeDetail.fetch(restaurant.place_id, restaurant.name, restaurant.address);
  }, [slots, placeDetail]);

  const handleCloseModal = useCallback(() => {
    setInspectedIndex(null);
    placeDetail.clear();
  }, [placeDetail]);

  const handleChooseFromComparison = useCallback((restaurant: Restaurant) => {
    setChosenWinner(restaurant);
    setIsComparing(false);
  }, []);

  const handleUndecide = useCallback(() => {
    setChosenWinner(null);
    setIsComparing(false);
    undecide();
  }, [undecide]);

  const allLocked = locked.every(Boolean);
  const hasAny = slots.some(Boolean);
  const lockedCount = locked.filter(Boolean).length;
  const isAnimating = isSpinning || isFinalSpinning;
  const lockedRestaurants = slots.filter((r, i) => locked[i] && r !== null) as Restaurant[];
  const canCompare = lockedCount === 2 && hasAny && !isAnimating && status === "landed" && !isComparing;

  const winner =
    chosenWinner ??
    (isDecided ? (slots.find((_, i) => locked[i]) ?? slots.find(Boolean) ?? null) : null);
  const showWinner = !!winner;

  return (
    <div className="slot-machine">
      {/* Header */}
      <header className="machine-header">
        <div className="header-badge">🎰</div>
        <h1 className="machine-title">Restaurant<br />Roulette</h1>
        <p className="machine-tagline">Three options. One dinner. No regrets.</p>
        <SpinCounter count={spinCount} />
      </header>

      {/* Controls + filters — hide during comparison or winner */}
      {!isComparing && !showWinner && (
        <>
          <div className="controls-bar">
            <div className="radius-selector">
              <span className="radius-label">Radius</span>
              {RADIUS_OPTIONS.map((opt) => (
                <button
                  key={opt.value}
                  className={`radius-btn ${radius === opt.value ? "radius-btn--active" : ""}`}
                  onClick={() => setRadius(opt.value)}
                >
                  {opt.label}
                </button>
              ))}
            </div>
            <GeolocationButton onLocate={handleFetchAndSpin} />
          </div>

          <FilterPanel
            pool={pool}
            filters={filters}
            onChange={setFilters}
            filteredCount={filteredPool.length}
          />
        </>
      )}

      {/* Error banner */}
      {error && !showWinner && !isComparing && (
        <div className="info-banner">
          <span>ℹ️</span> {error}
        </div>
      )}

      {/* Winner banner */}
      {showWinner && winner && (
        <WinnerBanner winner={winner} onChangeMind={handleUndecide} />
      )}

      {/* Comparison view */}
      {isComparing && lockedRestaurants.length === 2 && (
        <ComparisonView
          restaurants={[lockedRestaurants[0], lockedRestaurants[1]]}
          onChoose={handleChooseFromComparison}
          onBack={() => setIsComparing(false)}
        />
      )}

      {/* Slot reel */}
      {!showWinner && (
        <div
          className={[
            "reel-area",
            isDecided ? "reel-area--decided" : "",
            isComparing ? "reel-area--comparing" : "",
          ].filter(Boolean).join(" ")}
        >
          <div className="reel-chrome reel-chrome--left" />
          <div className="slots-grid">
            {slots.map((restaurant, i) => (
              <RestaurantCard
                key={i}
                restaurant={restaurant}
                locked={locked[i]}
                onToggleLock={() => !isDecided && !isComparing && toggleLock(i)}
                onInspect={() => !isComparing && handleInspect(i)}
                spinning={isSpinning}
                finalSpinning={isFinalSpinning}
                index={i}
              />
            ))}
          </div>
          <div className="reel-chrome reel-chrome--right" />
        </div>
      )}

      {/* Action buttons */}
      {!showWinner && !isComparing && (
        <div className="action-row">
          {hasAny && !isAnimating && (
            <button className="btn-secondary" onClick={handleReset}>↺ Reset</button>
          )}

          {canCompare && (
            <button className="btn-compare" onClick={() => setIsComparing(true)}>
              ⚔️ Compare my 2 picks
            </button>
          )}

          {allLocked && !isAnimating ? (
            <button className="spin-btn spin-btn--final" onClick={finalSpin}>
              <span className="spin-icon">🎰</span> Final Spin!
            </button>
          ) : (
            <button
              className={`spin-btn ${isAnimating ? "spin-btn--spinning" : ""}`}
              onClick={handleSpin}
              disabled={isAnimating || loading}
            >
              {loading ? (
                <><span className="spinner-dot" /> Fetching…</>
              ) : isFinalSpinning ? (
                <><span className="spin-icon">🎲</span> Deciding…</>
              ) : isSpinning ? (
                <><span className="spin-icon">🎲</span> Spinning…</>
              ) : slots[0] === null ? (
                <><span className="spin-icon">🎰</span> Spin!</>
              ) : (
                <><span className="spin-icon">🎲</span> Re-spin</>
              )}
            </button>
          )}
        </div>
      )}

      {/* Helper text */}
      {hasAny && !isAnimating && !showWinner && !isComparing && (
        <p className="helper-text">
          {allLocked
            ? "All locked — hit Final Spin to commit!"
            : canCompare
            ? "Not feeling the 3rd? Compare your 2 locked picks head to head."
            : lockedCount > 0
            ? `${lockedCount} slot${lockedCount > 1 ? "s" : ""} locked — re-spin the rest`
            : "Lock in your favourites before re-spinning"}
        </p>
      )}

      {!located && !hasAny && (
        <p className="helper-text">
          Grant location access for real nearby results, or hit Spin to try the demo.
        </p>
      )}

      {/* Detail modal */}
      {inspectedIndex !== null && (
        <PlaceDetailModal
          detail={placeDetail.detail}
          loading={placeDetail.loading}
          error={placeDetail.error}
          onClose={handleCloseModal}
          photoUrl={slots[inspectedIndex]?.photo_url ?? null}
        />
      )}
    </div>
  );
}
