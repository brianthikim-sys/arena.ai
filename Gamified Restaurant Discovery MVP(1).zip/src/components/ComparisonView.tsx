import type { Restaurant } from "../hooks/useRestaurantRoulette";

interface Props {
  restaurants: [Restaurant, Restaurant];
  onChoose: (r: Restaurant) => void;
  onBack: () => void;
}

function Stars({ rating }: { rating: number | null }) {
  if (rating === null) return null;
  const full = Math.floor(rating);
  const frac = rating - full;
  return (
    <span className="cmp-stars">
      {Array.from({ length: 5 }, (_, i) => {
        const cls =
          i < full ? "star filled" : i === full && frac >= 0.5 ? "star half" : "star empty";
        return <span key={i} className={cls}>★</span>;
      })}
      <span className="cmp-rating-num">{rating.toFixed(1)}</span>
    </span>
  );
}

function Price({ level }: { level: number | null }) {
  if (level === null) return null;
  return (
    <span className="cmp-price">
      {"$".repeat(level)}
      <span style={{ opacity: 0.3 }}>{"$".repeat(Math.max(0, 4 - level))}</span>
    </span>
  );
}

function ComparisonCard({
  restaurant,
  side,
  onChoose,
}: {
  restaurant: Restaurant;
  side: "left" | "right";
  onChoose: () => void;
}) {
  const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
    restaurant.name + " " + restaurant.address
  )}`;

  return (
    <div className={`cmp-card cmp-card--${side}`}>
      {/* Photo */}
      <div className="cmp-photo-wrap">
        {restaurant.photo_url ? (
          <img src={restaurant.photo_url} alt={restaurant.name} className="cmp-photo" />
        ) : (
          <div className="cmp-photo cmp-photo--placeholder">🍽️</div>
        )}
        <div className="cmp-photo-fade" />

        {/* Badges on photo */}
        <div className="cmp-photo-badges">
          {restaurant.open_now !== null && (
            <span className={`open-badge ${restaurant.open_now ? "open-badge--open" : "open-badge--closed"}`}>
              {restaurant.open_now ? "OPEN" : "CLOSED"}
            </span>
          )}
          <Price level={restaurant.price_level} />
        </div>
      </div>

      {/* Body */}
      <div className="cmp-body">
        <h2 className="cmp-name">{restaurant.name}</h2>

        <div className="cmp-meta">
          <Stars rating={restaurant.rating} />
          {restaurant.user_ratings_total > 0 && (
            <span className="cmp-review-count">
              {restaurant.user_ratings_total.toLocaleString()} reviews
            </span>
          )}
        </div>

        <p className="cmp-address">📍 {restaurant.address}</p>

        {restaurant.types.length > 0 && (
          <div className="type-tags">
            {restaurant.types.slice(0, 3).map((t) => (
              <span key={t} className="type-tag">
                {t.replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase())}
              </span>
            ))}
          </div>
        )}

        <a
          href={mapsUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="cmp-maps-link"
        >
          🗺️ Open in Maps
        </a>
      </div>

      {/* CTA */}
      <button className="cmp-choose-btn" onClick={onChoose}>
        Choose {restaurant.name.split(" ")[0]}
      </button>
    </div>
  );
}

export default function ComparisonView({ restaurants, onChoose, onBack }: Props) {
  const [a, b] = restaurants;

  return (
    <div className="cmp-root">
      <div className="cmp-header">
        <button className="btn-secondary cmp-back-btn" onClick={onBack}>
          ← Back
        </button>
        <p className="cmp-headline">Head to head</p>
      </div>

      <div className="cmp-grid">
        <ComparisonCard restaurant={a} side="left" onChoose={() => onChoose(a)} />

        <div className="cmp-vs">
          <span className="cmp-vs-text">VS</span>
        </div>

        <ComparisonCard restaurant={b} side="right" onChoose={() => onChoose(b)} />
      </div>
    </div>
  );
}
