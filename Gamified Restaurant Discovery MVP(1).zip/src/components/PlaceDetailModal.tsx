import { useEffect, useRef } from "react";
import type { PlaceDetail } from "../hooks/usePlaceDetail";

interface Props {
  detail: PlaceDetail | null;
  loading: boolean;
  error: string | null;
  onClose: () => void;
  photoUrl: string | null;
}

function PriceDots({ level }: { level: number | null }) {
  if (level === null) return null;
  return (
    <span className="detail-price">
      {"$".repeat(level)}
      <span style={{ opacity: 0.3 }}>{"$".repeat(Math.max(0, 4 - level))}</span>
    </span>
  );
}

function HoursBlock({ hours }: { hours: NonNullable<PlaceDetail["hours"]> }) {
  const today = new Date().getDay(); // 0 = Sun
  // weekday_text is Mon-Sun (index 0-6), but JS getDay is Sun=0, Mon=1…
  const todayIndex = today === 0 ? 6 : today - 1;

  return (
    <div className="detail-hours">
      {hours.weekday_text.map((line, i) => (
        <div
          key={i}
          className={`hours-row ${i === todayIndex ? "hours-row--today" : ""}`}
        >
          {line}
        </div>
      ))}
    </div>
  );
}

function ReviewCard({ review }: { review: PlaceDetail["reviews"][number] }) {
  return (
    <div className="review-card">
      <div className="review-header">
        <span className="review-author">{review.author_name}</span>
        <span className="review-stars">
          {"★".repeat(review.rating)}
          <span style={{ opacity: 0.25 }}>{"★".repeat(5 - review.rating)}</span>
        </span>
        <span className="review-time">{review.relative_time_description}</span>
      </div>
      <p className="review-text">{review.text}</p>
    </div>
  );
}

export default function PlaceDetailModal({ detail, loading, error, onClose, photoUrl }: Props) {
  const overlayRef = useRef<HTMLDivElement>(null);

  // Close on Escape
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", handler);
    return () => document.removeEventListener("keydown", handler);
  }, [onClose]);

  // Trap scroll
  useEffect(() => {
    document.body.style.overflow = "hidden";
    return () => { document.body.style.overflow = ""; };
  }, []);

  const handleOverlayClick = (e: React.MouseEvent) => {
    if (e.target === overlayRef.current) onClose();
  };

  return (
    <div className="modal-overlay" ref={overlayRef} onClick={handleOverlayClick} role="dialog" aria-modal>
      <div className="modal-panel">
        {/* Close button */}
        <button className="modal-close" onClick={onClose} aria-label="Close">✕</button>

        {loading && (
          <div className="modal-loading">
            <span className="spinner-dot" style={{ width: 16, height: 16 }} />
            <span>Loading details…</span>
          </div>
        )}

        {!loading && detail && (
          <>
            {/* Hero photo */}
            {photoUrl && (
              <div className="modal-photo-wrap">
                <img src={photoUrl} alt={detail.name} className="modal-photo" />
                <div className="modal-photo-fade" />
              </div>
            )}

            <div className="modal-body">
              {/* Name + meta */}
              <div className="modal-meta-row">
                {detail.rating !== null && (
                  <span className="modal-rating">★ {detail.rating.toFixed(1)}</span>
                )}
                <PriceDots level={detail.price_level} />
                {detail.hours?.open_now !== null && (
                  <span className={`modal-open-tag ${detail.hours?.open_now ? "open" : "closed"}`}>
                    {detail.hours?.open_now ? "Open now" : "Closed"}
                  </span>
                )}
              </div>

              <h2 className="modal-name">{detail.name}</h2>
              <p className="modal-address">📍 {detail.address}</p>

              {error && <p className="modal-error-note">{error}</p>}

              {/* Contact + links */}
              <div className="modal-actions">
                <a
                  href={detail.maps_url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="modal-link-btn modal-link-btn--maps"
                >
                  🗺️ Open in Google Maps
                </a>
                {detail.website && (
                  <a
                    href={detail.website}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="modal-link-btn"
                  >
                    🌐 Website / Menu
                  </a>
                )}
                {detail.phone && (
                  <a href={`tel:${detail.phone}`} className="modal-link-btn">
                    📞 {detail.phone}
                  </a>
                )}
              </div>

              {/* Hours */}
              {detail.hours && detail.hours.weekday_text.length > 0 && (
                <div className="modal-section">
                  <h3 className="modal-section-title">Hours</h3>
                  <HoursBlock hours={detail.hours} />
                </div>
              )}

              {/* Reviews */}
              {detail.reviews.length > 0 && (
                <div className="modal-section">
                  <h3 className="modal-section-title">Reviews</h3>
                  <div className="reviews-list">
                    {detail.reviews.slice(0, 3).map((r, i) => (
                      <ReviewCard key={i} review={r} />
                    ))}
                  </div>
                </div>
              )}

              {detail.reviews.length === 0 && !error && (
                <p className="modal-no-reviews">No reviews available. Start the backend server with a Google Places API key to see live data.</p>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
