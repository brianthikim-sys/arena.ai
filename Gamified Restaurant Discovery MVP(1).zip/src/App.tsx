import SlotMachine from "./components/SlotMachine";

export default function App() {
  return (
    <div className="app-root">
      <SlotMachine />
    </div>
  );
}
