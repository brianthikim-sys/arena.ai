import { useState, useCallback, useRef } from "react";
import { MOCK_RESTAURANTS } from "../data/mockRestaurants";

export interface Restaurant {
  place_id: string;
  name: string;
  address: string;
  rating: number | null;
  user_ratings_total: number;
  price_level: number | null;
  photo_url: string | null;
  photo_reference?: string | null;
  types: string[];
  open_now: boolean | null;
}

type SpinStatus = "idle" | "spinning" | "landed" | "final-spinning" | "decided";

const COOLDOWN_MAX = 6;
const API_BASE = import.meta.env.VITE_API_URL || "http://localhost:3001";
const SPIN_DURATION_MS = 1400;

function pickRandom<T>(pool: T[]): T {
  return pool[Math.floor(Math.random() * pool.length)];
}

// Pick `count` unique items from pool, excluding all ids in the exclusion set
function pickUnique(
  pool: Restaurant[],
  count: number,
  excludeIds: Set<string>
): Restaurant[] {
  const available = pool.filter((r) => !excludeIds.has(r.place_id));

  // If pool is too small after exclusions, relax cooldown partially
  const source = available.length >= count ? available : pool;

  const chosen: Restaurant[] = [];
  const used = new Set<string>();

  while (chosen.length < count && chosen.length < source.length) {
    const candidate = pickRandom(source.filter((r) => !used.has(r.place_id)));
    if (candidate) {
      chosen.push(candidate);
      used.add(candidate.place_id);
    }
  }

  return chosen;
}

export function useRestaurantRoulette() {
  const [pool, setPool] = useState<Restaurant[]>(MOCK_RESTAURANTS);
  const [slots, setSlots] = useState<(Restaurant | null)[]>([null, null, null]);
  const [locked, setLocked] = useState<boolean[]>([false, false, false]);
  const [status, setStatus] = useState<SpinStatus>("idle");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [spinCount, setSpinCount] = useState(0);
  const cooldownQueue = useRef<string[]>([]);

  // Push rejected restaurants into cooldown, evicting oldest when full
  const pushCooldown = useCallback((ids: string[]) => {
    cooldownQueue.current = [
      ...cooldownQueue.current,
      ...ids,
    ].slice(-COOLDOWN_MAX);
  }, []);

  const fetchByLocation = useCallback(
    async (lat: number, lng: number, radius = 1500) => {
      setLoading(true);
      setError(null);
      try {
        const res = await fetch(
          `${API_BASE}/api/restaurants?lat=${lat}&lng=${lng}&radius=${radius}`
        );
        if (!res.ok) throw new Error(`API error ${res.status}`);
        const data = await res.json();
        const restaurants: Restaurant[] = data.restaurants.map((r: Restaurant & { photo_reference?: string }) => ({
          ...r,
          photo_url: r.photo_reference
            ? `${API_BASE}/api/photo/${r.photo_reference}?maxwidth=600`
            : null,
        }));
        if (restaurants.length === 0) throw new Error("No restaurants found nearby");
        setPool(restaurants);
        return restaurants;
      } catch (err) {
        const msg = err instanceof Error ? err.message : "Unknown error";
        setError(`Using demo data — ${msg}`);
        return MOCK_RESTAURANTS;
      } finally {
        setLoading(false);
      }
    },
    []
  );

  // Final spin: all 3 locked, animate all slots then settle as "decided"
  const finalSpin = useCallback(() => {
    if (status === "final-spinning" || status === "decided") return;
    setStatus("final-spinning");
    setTimeout(() => {
      setStatus("decided");
    }, SPIN_DURATION_MS);
  }, [status]);

  const spin = useCallback(
    (currentPool?: Restaurant[]) => {
      if (status === "spinning" || status === "final-spinning") return;

      const source = currentPool || pool;
      setStatus("spinning");
      setSpinCount((n) => n + 1);

      // Collect IDs of currently visible, unlocked slots to push to cooldown
      const toReject = slots
        .map((r, i) => (!locked[i] && r ? r.place_id : null))
        .filter(Boolean) as string[];
      pushCooldown(toReject);

      setTimeout(() => {
        const exclude = new Set(cooldownQueue.current);

        // Keep locked slots, fill unlocked with new picks
        const unlockedCount = locked.filter((l) => !l).length;
        const newPicks = pickUnique(source, unlockedCount, exclude);

        let pickIndex = 0;
        const nextSlots = slots.map((existing, i) => {
          if (locked[i]) return existing;
          return newPicks[pickIndex++] ?? existing;
        });

        setSlots(nextSlots);
        setStatus("landed");
      }, SPIN_DURATION_MS);
    },
    [status, pool, slots, locked, pushCooldown]
  );

  const toggleLock = useCallback((index: number) => {
    setLocked((prev) => prev.map((v, i) => (i === index ? !v : v)));
  }, []);

  const reset = useCallback(() => {
    setSlots([null, null, null]);
    setLocked([false, false, false]);
    setStatus("idle");
    setSpinCount(0);
    cooldownQueue.current = [];
  }, []);

  const undecide = useCallback(() => {
    setStatus("landed");
  }, []);

  // Shortcut: spin immediately with fresh pool after location fetch
  const fetchAndSpin = useCallback(
    async (lat: number, lng: number, radius?: number) => {
      const freshPool = await fetchByLocation(lat, lng, radius);
      spin(freshPool);
    },
    [fetchByLocation, spin]
  );

  return {
    pool,
    slots,
    locked,
    status,
    spinCount,
    loading,
    error,
    spin,
    finalSpin,
    undecide,
    toggleLock,
    reset,
    fetchAndSpin,
    fetchByLocation,
    isSpinning: status === "spinning",
    isFinalSpinning: status === "final-spinning",
    isDecided: status === "decided",
  };
}
