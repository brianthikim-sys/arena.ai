import { useState, useCallback } from "react";

export interface PlaceHours {
  weekday_text: string[];
  open_now: boolean | null;
}

export interface PlaceReview {
  author_name: string;
  rating: number;
  text: string;
  relative_time_description: string;
}

export interface PlaceDetail {
  place_id: string;
  name: string;
  address: string;
  phone: string | null;
  website: string | null;
  maps_url: string;
  rating: number | null;
  price_level: number | null;
  hours: PlaceHours | null;
  reviews: PlaceReview[];
  types: string[];
}

const API_BASE = import.meta.env.VITE_API_URL || "http://localhost:3001";

// Fallback detail built from mock data so the modal works without the backend
function mockDetail(placeId: string, name: string, address: string): PlaceDetail {
  return {
    place_id: placeId,
    name,
    address,
    phone: null,
    website: null,
    maps_url: `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(name + " " + address)}`,
    rating: null,
    price_level: null,
    hours: null,
    reviews: [],
    types: [],
  };
}

export function usePlaceDetail() {
  const [detail, setDetail] = useState<PlaceDetail | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetch = useCallback(
    async (placeId: string, fallbackName = "", fallbackAddress = "") => {
      setLoading(true);
      setError(null);
      try {
        const res = await window.fetch(`${API_BASE}/api/details/${encodeURIComponent(placeId)}`);
        if (!res.ok) throw new Error(`API error ${res.status}`);
        const data: PlaceDetail = await res.json();
        setDetail(data);
      } catch (err) {
        // Degrade gracefully: show a minimal detail panel from what we already know
        setError("Full details unavailable — showing basic info");
        setDetail(mockDetail(placeId, fallbackName, fallbackAddress));
      } finally {
        setLoading(false);
      }
    },
    []
  );

  const clear = useCallback(() => {
    setDetail(null);
    setError(null);
  }, []);

  return { detail, loading, error, fetch, clear };
}
