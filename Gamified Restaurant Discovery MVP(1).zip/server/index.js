require("dotenv").config();
const express = require("express");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

const API_KEY = process.env.GOOGLE_PLACES_API_KEY;

if (!API_KEY) {
  console.warn("WARNING: GOOGLE_PLACES_API_KEY is not set in .env");
}

// Strip down Place result to only what the frontend needs
function mapPlace(place) {
  return {
    place_id: place.place_id,
    name: place.name,
    address: place.vicinity || "",
    rating: place.rating ?? null,
    user_ratings_total: place.user_ratings_total ?? 0,
    price_level: place.price_level ?? null,
    photo_reference: place.photos?.[0]?.photo_reference ?? null,
    types: (place.types || []).filter(
      (t) => !["point_of_interest", "establishment", "food"].includes(t)
    ),
    open_now: place.opening_hours?.open_now ?? null,
  };
}

// GET /api/restaurants?lat=...&lng=...&radius=...
app.get("/api/restaurants", async (req, res) => {
  const { lat, lng, radius = 1500 } = req.query;

  if (!lat || !lng) {
    return res.status(400).json({ error: "lat and lng query params are required" });
  }

  if (!API_KEY) {
    return res.status(500).json({ error: "Server API key not configured" });
  }

  try {
    const url = new URL(
      "https://maps.googleapis.com/maps/api/place/nearbysearch/json"
    );
    url.searchParams.set("location", `${lat},${lng}`);
    url.searchParams.set("radius", radius);
    url.searchParams.set("type", "restaurant");
    url.searchParams.set("key", API_KEY);

    const response = await fetch(url.toString());
    if (!response.ok) {
      throw new Error(`Places API responded with ${response.status}`);
    }

    const data = await response.json();

    if (data.status !== "OK" && data.status !== "ZERO_RESULTS") {
      console.error("Places API error:", data.status, data.error_message);
      return res
        .status(502)
        .json({ error: `Places API error: ${data.status}` });
    }

    const restaurants = (data.results || []).map(mapPlace);
    res.json({ restaurants, count: restaurants.length });
  } catch (err) {
    console.error("Failed to fetch restaurants:", err.message);
    res.status(500).json({ error: "Failed to fetch restaurants" });
  }
});

// GET /api/details/:place_id — full place details (hours, website, reviews, phone)
app.get("/api/details/:place_id", async (req, res) => {
  if (!API_KEY) {
    return res.status(500).json({ error: "Server API key not configured" });
  }

  const { place_id } = req.params;
  const fields = [
    "place_id", "name", "formatted_address", "formatted_phone_number",
    "website", "url", "rating", "price_level", "opening_hours", "reviews",
    "types",
  ].join(",");

  try {
    const url = new URL("https://maps.googleapis.com/maps/api/place/details/json");
    url.searchParams.set("place_id", place_id);
    url.searchParams.set("fields", fields);
    url.searchParams.set("key", API_KEY);

    const response = await fetch(url.toString());
    if (!response.ok) throw new Error(`Places API responded with ${response.status}`);

    const data = await response.json();
    if (data.status !== "OK") {
      return res.status(502).json({ error: `Places API: ${data.status}` });
    }

    const p = data.result;
    res.json({
      place_id: p.place_id,
      name: p.name,
      address: p.formatted_address || "",
      phone: p.formatted_phone_number || null,
      website: p.website || null,
      maps_url: p.url || `https://www.google.com/maps/place/?q=place_id:${place_id}`,
      rating: p.rating ?? null,
      price_level: p.price_level ?? null,
      hours: p.opening_hours
        ? {
            open_now: p.opening_hours.open_now ?? null,
            weekday_text: p.opening_hours.weekday_text || [],
          }
        : null,
      reviews: (p.reviews || []).map((r) => ({
        author_name: r.author_name,
        rating: r.rating,
        text: r.text,
        relative_time_description: r.relative_time_description,
      })),
      types: (p.types || []).filter(
        (t) => !["point_of_interest", "establishment", "food"].includes(t)
      ),
    });
  } catch (err) {
    console.error("Failed to fetch place details:", err.message);
    res.status(500).json({ error: "Failed to fetch place details" });
  }
});

// GET /api/photo/:reference — proxy so the API key never touches the frontend
app.get("/api/photo/:reference", (req, res) => {
  if (!API_KEY) {
    return res.status(500).json({ error: "Server API key not configured" });
  }

  const { reference } = req.params;
  const maxwidth = req.query.maxwidth || 600;

  const url = new URL(
    "https://maps.googleapis.com/maps/api/place/photo"
  );
  url.searchParams.set("maxwidth", maxwidth);
  url.searchParams.set("photo_reference", reference);
  url.searchParams.set("key", API_KEY);

  res.redirect(url.toString());
});

// Health check
app.get("/api/health", (_req, res) => res.json({ ok: true }));

const PORT = process.env.PORT || 3001;
app.listen(PORT, () =>
  console.log(`Restaurant Roulette API running on http://localhost:${PORT}`)
);
